var app = angular.module("ChatApp", ['ngRoute']); // declare angular app
var log = console.log.bind(console);

app.config(['$routeProvider',function ($routeProvider) {
    $routeProvider.
    when('/', {
        template: "",
        controller: 'ChatAppController'
    }).
    otherwise({
            redirectTo: '/' // route to index.html
        });
}]);

app.controller("ChatAppController", function ($scope,ChatAppService) {
    $scope.msgArray = []; 
    
    $scope.messages = function(msg){
        $scope.msgArray.push(msg); // save msg to an array

        //ChatAppService.putChatHistory($scope.msgArray) // send msg to service
        
    }
});


app.service("ChatAppService", ['$http', function ($http) {

    this.putChatHistory = function (data) {
        return $http.post('/save',data); // call $http POST method from angular to node server
    };
    
}]);