var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var fs = require('fs');
var bodyParser =require('body-parser');

app.use(express.static(__dirname + '/Public'));

app.get('/', function (req, res) {
    res.sendFile(__dirname + '/Public/Views/index.html');
});

// mongo DB dependencies 
var Db=require("mongodb").Db,MongoClient=require("mongodb").MongoClient,Server=require("mongodb").Server,ReplSetServers=require("mongodb").ReplSetServers,ObjectID=require("mongodb").ObjectID,Binary=require("mongodb").Binary,GridStore=require("mongodb").GridStore,Grid=require("mongodb").Grid,Code=require("mongodb").Code,BSON=require("mongodb").pure().BSON,assert=require("assert");

// create instance of mongo db on port 27017
var connection =  "mongodb://webchatapp:webchatapp@ds061691.mongolab.com:61691/webchatapp";
var db = new Db('ChatDB', new Server("localhost",27017),{safe:false});

////////////// socket.io ///////////////
io.on('connection', function (socket) {
    console.log('a user connected');
    
    socket.on('disconnect', function(){
        // on disconnect drop previous collection
        db.open(function(err, db) {
            db.dropCollection("chatHistory",function(err,result){
                console.log(result);
                db.close();
            })
        });
        console.log('user disconnected');
    });
    
    socket.on('chat message', function (msg) {
        console.log("message:- "+ msg);
        io.emit('chat message',msg);
        
        // while chat message is entered open database and insert msg
        db.open(function(err, db) {
          var collection = db.collection("chatHistory");
          collection.insert([{msg:msg}], {w:1}, function(err, result) {
            assert.equal(null, err);
            db.close();
        });
      });
    })
});


// // save data to json file
app.post('/save',bodyParser.json(),function(req,res){
    res.set('Content-Type', 'application/json'); // tell Angular that this is JSON
    var fileName = __dirname+'/Public/Data/ChatHistory.json';
    fs.readFile(fileName,'utf8',function(err,data){
        var chatHistory = JSON.stringify(req.body);
        fs.writeFile(fileName,chatHistory,[{encoding:'utf8',flag:'a'}],function(err){
            if(err){
                console.log(err);
            }else{
                console.log('file saved');
            }
        })
    });
    res.sendStatus(200);
})

app.listen(process.env.PORT, process.env.IP);
http.listen(3000, function(){
    console.log('listening on *:3000'); // open port 3000 and let app listen to it

});



