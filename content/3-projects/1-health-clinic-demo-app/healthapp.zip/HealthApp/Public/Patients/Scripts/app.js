var app = angular.module("myApp", ['ngRoute']);

app.config(['$routeProvider',
    function ($routeProvider) {
        $routeProvider.
        when('/PatientList', {
            templateUrl: 'PatientList.html',
            controller: 'PatientList'
        }).
        when('/PatientDetails', {
            templateUrl: 'PatientDetails.html',
            controller: 'PatientDetails'
        }).
        otherwise({
            redirectTo: '/PatientList'
        });
    }]);

app.controller("PatientList", function ($scope, $location, Patient) {
		// call Patient Service and get all patient from JSON file
    Patient.getPatient().success(function (data) {
        $scope.patientModel = data; // store patient in patientModel variable on scope level 
    });	
		// if user select patient then point user to patient details page along with clicked patient information
    $scope.selectedPatient = function (patient) {
        $location.path('/PatientDetails');
        Patient.setPatientDetails(patient);
    };
		// simple on click reset method
    $scope.resetForm = function () {
        Patient.setPatientDetails('');
    };
});

app.controller("PatientDetails", function ($scope, Patient) {
				
    $scope.patient = {};
		// before we go to patient details page lets store selected patient information into patient object
    $scope.patient.firstName = Patient.getPatientDetails().firstName;
    $scope.patient.lastName = Patient.getPatientDetails().lastName;
    $scope.patient.phoneNo = Patient.getPatientDetails().phoneNo;
    $scope.patient.lastVisitDate = Patient.getPatientDetails().lastVisitDate;
    $scope.patient.Status = Patient.getPatientDetails().Status;
    
    $scope.resetForm = function () {
        $scope.patient = {};
    };

    $scope.submit = function (patient) {
        Patient.putPatient(patient);
    }
    

});


app.service("Patient", ['$http', function ($http) {
    var url = '../Data/Patient.json';
    var patientDetails = '';

    this.getPatient = function () {
        return $http.get(url);
    };
    
    this.putPatient = function (data) {
        return $http.post('/save',data);
    };

    this.getPatientDetails = function () {
        return patientDetails;
    };
    this.setPatientDetails = function (value) {
        patientDetails = value;
    };

}]);