var http = require('http');
var express = require('express');
var fs = require('fs');
var bodyParser =require('body-parser');

var app = express();
// open port 5000
var port = process.env.PORT || 5000;
//forward user to static directory.  
app.use(express.static( __dirname + '/Public/Patients'));
// home route '/'
app.get('/', function (req, res) {
    res.sendFile( __dirname + '/Public/Patients/Views/index.html');
});
// handling '/save' request and parsing request body using bodyParser module 
app.post('/save',bodyParser.json(),function(req,res){
    var fileName = __dirname+'/Public/Patients/Data/Patient.json'; // accessing json data
    var patientData = [];
    
    patientData.push(JSON.stringify("firstName")+":"+JSON.stringify(req.body.firstName));
    patientData.push(JSON.stringify("lastName")+":"+JSON.stringify(req.body.lastName));
    patientData.push(JSON.stringify("phoneNo")+":"+JSON.stringify(req.body.phoneNo));   patientData.push(JSON.stringify("lastVisitDate")+":"+JSON.stringify(req.body.lastVisitDate));
    patientData.push(JSON.stringify("Status")+":"+JSON.stringify(req.body.Status));

		// first read json file
    fs.readFile(fileName,'utf8',function(err,data){
        var body = data.replace("]",""); // replace closing tag with empty ""
        // then write data that just received via request from front-end form 
        fs.writeFile(fileName,body+",{"+patientData+"}]",[{encoding:'utf8',flag:'w'}],function(err)      {
        if(err){
            console.log(err);
        }else{
            console.log('file saved'); // console out msg
        }
    })
    });
})
app.listen(port); // listen port 5000
console.log('port running at '+port);




